import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class NumberGuessingGameGUI extends JFrame implements ActionListener {
    private int numberToGuess;
    private int attemptsLeft;
    private int round = 1;
    private int score = 0;

    private final int maxRounds = 3;
    private final int maxAttempts = 5;

    private JTextField inputField;
    private JLabel messageLabel, attemptsLabel, scoreLabel, roundLabel;
    private JButton guessButton, restartButton;

    public NumberGuessingGameGUI() {
        setTitle("🎯 Number Guessing Game");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // center the frame

        initComponents();
        startNewRound();

        setVisible(true);
    }

    private void initComponents() {
        // Layout
        setLayout(new BorderLayout());

        // North: Round info
        JPanel topPanel = new JPanel(new GridLayout(2, 1));
        roundLabel = new JLabel("Round 1 of " + maxRounds, SwingConstants.CENTER);
        roundLabel.setFont(new Font("Arial", Font.BOLD, 18));
        topPanel.add(roundLabel);

        attemptsLabel = new JLabel("Attempts Left: " + maxAttempts, SwingConstants.CENTER);
        topPanel.add(attemptsLabel);
        add(topPanel, BorderLayout.NORTH);

        // Center: Message + input
        JPanel centerPanel = new JPanel(new GridLayout(3, 1));
        messageLabel = new JLabel("Guess a number between 1 and 100", SwingConstants.CENTER);
        inputField = new JTextField();
        centerPanel.add(messageLabel);
        centerPanel.add(inputField);
        add(centerPanel, BorderLayout.CENTER);

        // South: Buttons + Score
        JPanel bottomPanel = new JPanel(new GridLayout(2, 1));

        guessButton = new JButton("Submit Guess");
        guessButton.addActionListener(this);
        bottomPanel.add(guessButton);

        JPanel scorePanel = new JPanel(new FlowLayout());
        scoreLabel = new JLabel("Score: 0");
        restartButton = new JButton("Restart Game");
        restartButton.addActionListener(e -> restartGame());
        restartButton.setEnabled(false);

        scorePanel.add(scoreLabel);
        scorePanel.add(restartButton);
        bottomPanel.add(scorePanel);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void startNewRound() {
        numberToGuess = new Random().nextInt(100) + 1;
        attemptsLeft = maxAttempts;
        attemptsLabel.setText("Attempts Left: " + attemptsLeft);
        roundLabel.setText("Round " + round + " of " + maxRounds);
        messageLabel.setText("Guess a number between 1 and 100");
        inputField.setText("");
        inputField.requestFocus();
    }

    private void restartGame() {
        score = 0;
        round = 1;
        restartButton.setEnabled(false);
        guessButton.setEnabled(true);
        startNewRound();
        scoreLabel.setText("Score: 0");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String guessText = inputField.getText();
        int guess;

        try {
            guess = Integer.parseInt(guessText);
        } catch (NumberFormatException ex) {
            messageLabel.setText("❌ Enter a valid number!");
            return;
        }

        attemptsLeft--;
        attemptsLabel.setText("Attempts Left: " + attemptsLeft);

        if (guess == numberToGuess) {
            int points = (maxAttempts - attemptsLeft) * 10;
            score += (100 - points);
            scoreLabel.setText("Score: " + score);
            messageLabel.setText("✅ Correct! You earned " + (100 - points) + " points.");
            proceedToNextRound();
        } else if (guess < numberToGuess) {
            messageLabel.setText("📉 Too low! Try again.");
        } else {
            messageLabel.setText("📈 Too high! Try again.");
        }

        if (attemptsLeft == 0 && guess != numberToGuess) {
            messageLabel.setText("❌ Out of attempts! Number was: " + numberToGuess);
            proceedToNextRound();
        }

        inputField.setText("");
    }

    private void proceedToNextRound() {
        if (round < maxRounds) {
            round++;
            JOptionPane.showMessageDialog(this, "Next Round Starting...");
            startNewRound();
        } else {
            guessButton.setEnabled(false);
            restartButton.setEnabled(true);
            JOptionPane.showMessageDialog(this, "🎉 Game Over!\nFinal Score: " + score);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(NumberGuessingGameGUI::new);
    }
}
